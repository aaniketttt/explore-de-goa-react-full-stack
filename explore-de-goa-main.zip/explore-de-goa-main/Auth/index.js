import Getstarted from "./Getstarted";
import Login from "./Login";
import Register from "./Register";
import Welcome from "./Welcome";

export {Welcome,Register,Login,Getstarted}