import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
  FlatList,
  Alert,
  ToastAndroid
} from "react-native";
import React, { useState, useEffect } from "react";
import { TextInput, Button } from "react-native-paper";
import {BASE_URL,PATH} from "../Api/index";
import AsyncStorage from '@react-native-async-storage/async-storage';
import Spinner from 'react-native-loading-spinner-overlay';
import axios from "axios";

 
const window = {
  width: Dimensions.get("window").width,
  height: Dimensions.get("window").height,
};

const Register = ({navigation}) => {
  const [text, setText] = useState("");
  const [text2, setText2] = useState("");
  const [text3, setText3] = useState("");
  const [text4, setText4] = useState("");
  const [loader, setLoader] = useState(false);


  const maindata = async () =>
  {
    // setLoader(true)
    
    var registerCall = {
      method: 'post',
      url: BASE_URL + PATH.REGISTER,
      headers: {
        'Content-Type': 'application/json',
      },
      data: JSON.stringify({
        'username':text,
        'email':text2,
        'password':text3 ,
      }),
    };

    validateEmail = (email) => {
      var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }
 
  (  text && text2 && text3) ? 
  (
    validateEmail(text2) ?

    await axios(registerCall)
    .then(async(res) => {
          console.log(res.data);  
           
      await AsyncStorage.setItem('username',text); 
      await AsyncStorage.setItem('email',text2); 
      await AsyncStorage.setItem('password',text3);

         console.log(res.data.code);
         setLoader(false);
          if(res.status==200){
            navigation.navigate("Navigation");
          }
    })
    .catch((err) => {
      console.log(err.response.data);
      setLoader(false);

    })
    :
    setLoader(false),
    ToastAndroid.show('Invalid Email address', ToastAndroid.SHORT)

  )
:
setLoader(false)  ;
  }

  return (
    <View>
      <View style={{
        marginHorizontal: window.width * 0.1, display: 'flex', alignItems: 'center',
        justifyContent: 'center', textAlign: 'center', marginTop: window.height * 0.07
      }}>
        <Text style={{ fontSize: 30, fontWeight: "700" }}>Welcome Back</Text>
        <Text style={{
          display: 'flex', alignItems: 'center',
          justifyContent: 'center', textAlign: 'center', color: '#636363', marginTop: window.height * 0.01
        }}> Good to see you on our platform hope your journey with us will be memorable.</Text>
      </View>

      <View style={{ marginHorizontal: window.width * 0.05, marginTop: window.height * 0.05 }}>
        <TextInput
          style={{ width: window.width * 0.9 }}
          value={text}
          required={true}
          placeholder="Username"
          outlineStyle={{ borderRadius: 30, border: 0, backgroundColor: "#F6F6F6" }}
          mode="outlined"
          onChangeText={(text) => setText(text)}
        />

        <TextInput
          style={{ width: window.width * 0.9, marginTop: window.height * 0.02 }}
          value={text2}
          keyboardType="email-address"
          dataDetectorTypes={"address"}
          placeholder="Email"
          outlineStyle={{ borderRadius: 30, border: 0, backgroundColor: "#F6F6F6" }}
          mode="outlined"
          onChangeText={(text2) => setText2(text2)}
        />

        <TextInput
          style={{ width: window.width * 0.9, marginTop: window.height * 0.02 }}
          value={text3}
          secureTextEntry={true}
          placeholder="Password"
          outlineStyle={{ borderRadius: 30, border: 0, backgroundColor: "#F6F6F6" }}
          mode="outlined"
          onChangeText={(text3) => setText3(text3)}
        />

        {/* <TextInput
          style={{ width: window.width * 0.9, marginTop: window.height * 0.02 }}
          value={text4}
          secureTextEntry={true}
           placeholder="Confirm Password"
          outlineStyle={{ borderRadius: 30, border: 0, backgroundColor: "#F6F6F6" }}
          mode="outlined"
          onChangeText={(text4) => setText4(text4)}
        /> */}


        <TouchableOpacity 
        onPress={()=>maindata()}
        style={{ backgroundColor: '#0070F4', marginTop: window.height * 0.05, width: window.width * 0.9, borderRadius: 30, padding: window.width * 0.03, borderColor: "4px solid #C2DEFF" }}>
          <Text style={{ color: "#fff", textAlign: 'center', fontSize: 18, fontWeight: '500' }}>Confirm Password</Text>
        </TouchableOpacity>

        <View>

        </View>

        <View style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: window.height *0.02, flexDirection: 'row' }}>
          <Text>Already Registered? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('Login')}>
            <Text style={{ color: "#0070F4" }}>Sign In</Text></TouchableOpacity>
    </View>
      </View >
      <Spinner
           visible={loader} 
        />
    </View >
  )
}

export default Register