import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
  FlatList,
  Alert,
} from "react-native";
import React from 'react'


const window = {
  width: Dimensions.get("window").width,
  height: Dimensions.get("window").height,
};


const Welcome = ({ navigation }) => {
  return (
    <View>
      <Image source={require("../assets/welcome.png")} style={{
        width: window.width * 1,
        height: window.height * 1.1,
      }} />

      <View style={{
        position: 'absolute', display: 'flex',
        alignItems: 'center', justifyContent: 'center', marginTop: window.height * 0.13, marginHorizontal: window.width * 0.11
      }}>
        <View style={{
          display: 'flex',
          alignItems: 'center', justifyContent: 'center'
        }}>
          <Image source={require("../assets/explore.png")} style={{
            width: window.width * 0.5,
            height: window.height * 0.05,

          }} />
        </View>
        <View style={{ marginTop: window.height * 0.4 }}>
          <Text style={{ color: '#fff', textAlign: 'center', fontSize: 40, fontWeight: '700' }}>{`Let’s explore`}</Text>
          <Text style={{ color: '#fff', textAlign: 'center', fontSize: 40, fontWeight: '700' }}>{`the Goa together`}</Text>

          <Text style={{ color: '#fff', textAlign: 'center', fontSize: 15, fontWeight: '500', marginTop: window.height * 0.02 }}>We are your best travel Guide </Text>
        </View>

        <View style={{ backgroundColor: '#0070F4', marginTop: window.height * 0.1, width: window.width * 0.5, borderRadius: 30, padding: window.width * 0.03 }}>
          <TouchableOpacity onPress={()=> navigation.navigate('Getstarted')
          }>
            <Text style={{ color: "#fff", textAlign: 'center', fontSize: 15, fontWeight: '500' }}>{`Get Started ->`}</Text>
          </TouchableOpacity>
        </View>
      </View>



    </View>
  )
}

export default Welcome