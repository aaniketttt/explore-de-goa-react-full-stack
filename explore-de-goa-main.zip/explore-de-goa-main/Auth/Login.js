import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
  FlatList,
  Alert,
} from "react-native";
import React, { useState, useEffect } from "react";
import { TextInput, Button } from "react-native-paper";
import { Entypo } from '@expo/vector-icons';
import { AntDesign } from '@expo/vector-icons';
import axios from "axios";
import Spinner from 'react-native-loading-spinner-overlay';


import {BASE_URL,PATH} from "../Api/index";
import AsyncStorage from '@react-native-async-storage/async-storage';


const window = {
  width: Dimensions.get("window").width,
  height: Dimensions.get("window").height,
};

const Login = ({navigation}) => {
  const [text, setText] = useState("");
  const [text2, setText2] = useState("");
  const [text3, setText3] = useState("");
  const [loader, setLoader] = useState(false);


  const maindata = async () =>
  {
    setLoader(true)
    
    var registerCall = {
      method: 'post',
      url: BASE_URL + PATH.LOGIN,
      headers: {
        'Content-Type': 'application/json',
      },
      data: JSON.stringify({
        'email':text,
        'password':text2,
      }),
    };
    await axios(registerCall)
    .then(async(res) => {
          console.log(res.data);
          console.log(res.data.code);
          await AsyncStorage.setItem('username',res.data.user.username); 
          setLoader(false);
          if(res.status==200){
            navigation.pop(2)
            navigation.replace("Navigation");
          }
    })
    .catch((err) => {
      console.log(err);
      setLoader(false);

    });
  }
  return (
    <View>

      <View style={{
        marginHorizontal: window.width * 0.1, display: 'flex', alignItems: 'center',
        justifyContent: 'center', textAlign: 'center', marginTop: window.height * 0.07
      }}>
        <Text style={{ fontSize: 30, fontWeight: "700" }}>Welcome Back</Text>
        <Text style={{
          display: 'flex', alignItems: 'center',
          justifyContent: 'center', textAlign: 'center', color: '#636363', marginTop: window.height * 0.01
        }}> Let’s Explore the Unexplored and beautiful Destinations of Goa once again.</Text>
      </View>

      <View style={{ marginHorizontal: window.width * 0.05, marginTop: window.height * 0.05 }}>
        <TextInput
          style={{ width: window.width * 0.9 }}
          value={text}
          placeholder="Email"
          outlineStyle={{ borderRadius: 30, border: 0, backgroundColor: "#F6F6F6" }}
          mode="outlined"
          onChangeText={(text) => setText(text)}
        />

        <TextInput
          style={{ width: window.width * 0.9, marginTop: window.height * 0.02 }}
          value={text2}
          secureTextEntry={true}
          placeholder="Password"
          outlineStyle={{ borderRadius: 30, border: 0, backgroundColor: "#F6F6F6" }}
          mode="outlined"
          onChangeText={(text2) => setText2(text2)}
        />

        <View style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'flex-end', marginTop: window.height * 0.02 }}>
          <Text style={{ fontSize: 15, color: "#000", fontWeight: "600" }}>Forgot Password ?</Text>

        </View>

      <View style={{ backgroundColor: '#0070F4', marginTop: window.height * 0.1, width: window.width * 0.9, borderRadius: 30, padding: window.width * 0.03, borderColor: "4px solid #C2DEFF" }}>
      <TouchableOpacity onPress={() => maindata()}>
          <Text style={{ color: "#fff", textAlign: 'center', fontSize: 18, fontWeight: '500' }}>Sign in</Text></TouchableOpacity>
        </View>

        <View>

        </View>

        <View style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: window.height * .02 }}>
          <Text>Or Sign up With</Text>
          <View style={{ display: 'flex', flexDirection: 'row', marginTop: window.height * 0.02 }}>
            <TouchableOpacity >
              <AntDesign style={{ marginRight: window.width * 0.08, marginTop: window.height * 0.02 }} name="google" size={26} color="black" />

            </TouchableOpacity>
            <TouchableOpacity >
              <Entypo style={{ marginRight: window.width * 0.08, marginTop: window.height * 0.02 }} name="facebook-with-circle" size={26} color="black" />

            </TouchableOpacity>

            <TouchableOpacity >
              <AntDesign style={{ marginTop: window.height * 0.017 }} name="apple1" size={26} color="black" />

            </TouchableOpacity>
          </View>

        </View>
      </View>
      <Spinner
           visible={loader} 
        />
    </View>
  )
}

export default Login