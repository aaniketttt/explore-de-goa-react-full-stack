import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
  FlatList,
  Alert,
} from "react-native";
import React from 'react'


const window = {
  width: Dimensions.get("window").width,
  height: Dimensions.get("window").height,
};

const Getstarted = ({ navigation }) => {
  return (
    <View>
      <Image source={require("../assets/back.png")} style={{
        width: window.width * 1,
        height: window.height * 0.6,
      }} />
      <View style={{ marginHorizontal: window.width * 0.1, textAlign: 'center' }}>
        <Text style={{ color: '#0070F4', fontSize: 30, fontWeight: "800", textAlign: 'center' }}>Discover Your</Text>
        <Text style={{ color: '#0070F4', fontSize: 30, fontWeight: "800", textAlign: 'center' }}> Dream Tour </Text>

        <Text style={{ color: '#636363', fontSize: 14, fontWeight: "400", textAlign: 'center', marginTop: window.height * 0.02 }}>  Explore de Goa is a perfect perfect social
          media platform to explore the hidden and the
          beautiful destinations of Goa!</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <View style={{
          backgroundColor: '#0070F4', marginTop: window.height * 0.05, width: window.width * 0.8, borderRadius: 30, padding: window.width * 0.03, display: 'flex', alignItems: 'center',
          justifyContent: 'center', textAlign: 'center'
        }}>
          
            <Text style={{ color: "#fff", textAlign: 'center', fontSize: 15, fontWeight: '500' }}>Sign in</Text>
        </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text style={{
          color: '#636363', width: window.width * 0.8, borderRadius: 30, padding: window.width * 0.03, display: 'flex', alignItems: 'center',
          justifyContent: 'center', textAlign: 'center'
        }}>Register</Text>
          </TouchableOpacity>

      </View>



    </View>
  )
}

export default Getstarted