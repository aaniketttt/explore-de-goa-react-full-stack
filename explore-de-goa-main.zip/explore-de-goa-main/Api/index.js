const DOMAIN = 'https://goa-backend.onrender.com';
const API_VERSION = '/api/';

const BASE_URL = DOMAIN + API_VERSION;

const PATH = {
    UPLOAD: 'photo', 
    REGISTER:'user/register',
    LOGIN:'user/login',
    ADD_PLACES:'place/addPlace',
    PLACES:'place/getPlace',
    DETAILS:'place/place_details'
  };

export {BASE_URL, PATH};
