import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Welcome,Getstarted,Login,Register } from './Auth';
import Navigation from './layer/Navigation';
import { Places } from './layer';
import Like from './layer/Like';
const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName='Welcome'  
      screenOptions={{
    headerShown: false
  }}
  
  >
        <Stack.Screen name="Welcome" component={Welcome} />
        <Stack.Screen name="Getstarted" component={Getstarted} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Register" component={Register} />
        <Stack.Screen name="Navigation" component={Navigation} />
        <Stack.Screen name="Like" component={Like} />
        <Stack.Screen name="Places" component={Places} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
