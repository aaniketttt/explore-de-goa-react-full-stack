import {
    TouchableOpacity,
    View,
    Text,
    StyleSheet,
    Dimensions,
    Image,
    ScrollView,
    FlatList,
    Alert,
  } from "react-native";
import React from 'react'
import Home from './Home'
import Like from './Like'
import Notification from './Notification'
import Profile from './Profile'

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const Tab = createBottomTabNavigator();

const window = {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height,
  };

const Navigation = () => {
  return (
    <Tab.Navigator  
    screenOptions={
        ({ route }) => ({
          headerShown: false,
          tabBarStyle: { 
            backgroundColor:"#0070F4",
            elevation:20,
            borderTopWidth:0,
            position: "absolute",
            height:window.width*0.15, 
            borderRadius:45,
            marginBottom:window.width*0.05,
           marginHorizontal:window.width*0.05,
          },
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;
          if(route.name==="Home"){
            iconName = focused ? "active" : "inactive";
            return (
                <View
                  style={{
                    borderRadius: 200,
                    background: "#D6F0FF",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                { iconName=='inactive'? 
                 <View style={{ 
                 width: window.width*0.1,
                 height: window.width*0.07,
                 alignItems:"center",
                 justifyContent:"center", 
                 }}>
                <Image source={require("../assets/home1.png")}  style={{
                      width: window.width*0.06,
                      height: window.width*0.06,}}  /> 
                      </View>
                    :
                    <View style={{backgroundColor:"#69AEFF", 
                    width: window.width*0.14,
                    height: window.width*0.07,
                    alignItems:"center",
                    justifyContent:"center",
                    borderRadius:35,
                    padding:window.width*0.05 
                    }}> 
                        <Image  style={{
                         width: window.width*0.06,
                         height: window.width*0.06,}}  source={require("../assets/home1.png")}/>
                         
                    </View>
                      }
                </View>
              );
          } 
          else if(route.name==="Like"){
            iconName = focused ? "active" : "inactive";
            return (
                <View
                  style={{
                    borderRadius: 200,
                    background: "#D6F0FF",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                { iconName=='inactive'? 
                 <View style={{ 
                 width: window.width*0.1,
                 height: window.width*0.07,
                 alignItems:"center",
                 justifyContent:"center", 
                 }}>
                <Image source={require("../assets/addsquare.png")}  style={{
                      width: window.width*0.06,
                      height: window.width*0.06,}}  /> 
                      </View>
                    :
                    <View style={{backgroundColor:"#69AEFF", 
                    width: window.width*0.14,
                    height: window.width*0.07,
                    alignItems:"center",
                    justifyContent:"center",
                    borderRadius:35,
                    padding:window.width*0.05
  
                    }}>
  
  
                        <Image  style={{
                         width: window.width*0.06,
                         height: window.width*0.06,}}  source={require("../assets/addsquare.png")}/>
                         
                    </View>
                      }
                </View>
              );
          } 
          else if(route.name==="Notification"){
            iconName = focused ? "active" : "inactive";
            size = 30;
            return (
              <View
                style={{
                  borderRadius: 200,
                  background: "#D6F0FF",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
              { iconName=='inactive'? 
               <View style={{ 
               width: window.width*0.05,
               height: window.width*0.07,
               alignItems:"center",
               justifyContent:"center", 
               }}>
              <Image source={require("../assets/Bell.png")}  style={{
                    width: window.width*0.05,
                    height: window.width*0.06,}}  /> 
                    </View>
                  :
                  <View style={{backgroundColor:"#69AEFF", 
                  width: window.width*0.14,
                  height: window.width*0.07,
                  alignItems:"center",
                  justifyContent:"center",
                  borderRadius:35,
                  padding:window.width*0.05

                  }}>


                      <Image  style={{
                       width: window.width*0.05,
                       height: window.width*0.06,}}  source={require("../assets/Bell.png")}/>
                       
                  </View>
                    }
              </View>
            );
          } 
          else if (route.name === "Profile") {
            iconName = focused ? "active" : "inactive";
            size = 30;
            return (
              <View
                style={{
                  borderRadius: 200,
                  background: "#D6F0FF",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
              { iconName=='inactive'? 
               <View style={{ 
               width: window.width*0.1,
               height: window.width*0.07,
               alignItems:"center",
               justifyContent:"center", 
               }}>
              <Image source={require("../assets/People.png")}  style={{
                    width: window.width*0.05,
                    height: window.width*0.06,}}  /> 
                    </View>
                  :
                  <View style={{backgroundColor:"#69AEFF", 
                  width: window.width*0.14,
                  height: window.width*0.07,
                  alignItems:"center",
                  justifyContent:"center",
                  borderRadius:35,
                  padding:window.width*0.05

                  }}>


                      <Image  style={{
                       width: window.width*0.05,
                       height: window.width*0.06,}}  source={require("../assets/People.png")}/>
                       
                  </View>
                    }
              </View>
            );
          }
          
          
        },
      })}
      tabBarOptions={{
        showLabel:false
      }}
      >
      <Tab.Screen name="Home" component={Home} />
      <Tab.Screen name="Like" component={Like} />
      <Tab.Screen name="Notification" component={Notification} />
      <Tab.Screen name="Profile" component={Profile} />
    </Tab.Navigator>
  )
}

export default Navigation