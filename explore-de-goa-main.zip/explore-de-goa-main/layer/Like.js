import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
  SafeAreaView,
  FlatList,
  TextInput,
  Alert,
} from "react-native";
import Spinner from "react-native-loading-spinner-overlay";
import axios from "axios";
import { Rating } from 'react-native-ratings';
import { Platform } from "react-native";
import React, { useState } from "react"; 
import * as ImagePicker from "expo-image-picker";
import { Picker } from "@react-native-picker/picker";
import { BASE_URL, PATH } from "../Api";
import FormData from "form-data";
  
const window = {
  width: Dimensions.get("window").width,
  height: Dimensions.get("window").height,
};
var ratingst=0;
const Like = ({ navigation }) => {
  const [image, setImage] = useState(null);
  const [image2, setImage2] = useState(null);
  const [image3, setImage3] = useState(null);
  const [image4, setImage4] = useState(null);
  const [uploaded, setuploaded] = useState(null);
  const [uploaded2, setuploaded2] = useState(null);
  const [uploaded3, setuploaded3] = useState(null);
  const [uploaded4, setuploaded4] = useState(null);
  const [desc, setdesc] = useState(null);
  const [link, setlink] = useState(null);
  const [name, setName] = useState(null); 
  const [loader, setLoader] = useState(false);

   
  const [selectedLanguage, setSelectedLanguage] = useState('Goa');

  const pickImage = async () => {
    // No permissions request is necessary for launching the image library
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri);

      let localUri = result.assets[0].uri;
      let filename = localUri.split("/").pop(); 
 
      console.log("ufff", localUri); 
      setLoader(true);

      const uploadImage = async ( ) => {
        const formData = new FormData();
        formData.append('file', {
          uri: Platform.OS === 'android' ? localUri : filename,
          type: 'image/jpeg',
          name: 'filename.jpg',
        });
      
        try {
          const response = await axios.post('https://goa-backend.onrender.com/api/photo', formData, {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          });
      
          console.log('Image uploaded successfully:', response.data.secure_url);
          setuploaded(response.data.secure_url);
          setLoader(false);

        } catch (error) {
          console.error('Error uploading image:', error);
        }
      };
      uploadImage();
      
    }
    
  };
  // 2nf fun 
  const pickImage2 = async () => {
    // No permissions request is necessary for launching the image library
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setImage2(result.assets[0].uri);

      let localUri = result.assets[0].uri;
      let filename = localUri.split("/").pop(); 
 
      console.log("ufff", localUri); 
      setLoader(true);

      const uploadImage2 = async ( ) => {
        const formData = new FormData();
        formData.append('file', {
          uri: Platform.OS === 'android' ? localUri : filename,
          type: 'image/jpeg',
          name: 'filename.jpg',
        });
      
        try {
          const response = await axios.post('https://goa-backend.onrender.com/api/photo', formData, {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          });
      
          console.log('2Image uploaded successfully2:', response.data.secure_url);
          setuploaded2(response.data.secure_url);
          setLoader(false);


        } catch (error) {
          console.error('Error uploading image:', error);
        }
      };
      uploadImage2();
      
    }
    
  };

  // 3rd fun 
  const pickImage3 = async () => {
    // No permissions request is necessary for launching the image library
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setImage3(result.assets[0].uri);

      let localUri = result.assets[0].uri;
      let filename = localUri.split("/").pop(); 
 
      console.log("ufff3", localUri); 
      setLoader(true);

      const uploadImage3 = async ( ) => {
        const formData = new FormData();
        formData.append('file', {
          uri: Platform.OS === 'android' ? localUri : filename,
          type: 'image/jpeg',
          name: 'filename.jpg',
        });
      
        try {
          const response = await axios.post('https://goa-backend.onrender.com/api/photo', formData, {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          });
      
          console.log('3Image uploaded successfully3:', response.data.secure_url);
          setuploaded3(response.data.secure_url);
          setLoader(false);

        } catch (error) {
          console.error('Error uploading image:', error);
          setLoader(false);

        }
      };
      uploadImage3();
      
    }
    
  };
  const pickImage4 = async () => {
    // No permissions request is necessary for launching the image library
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setImage4(result.assets[0].uri);

      let localUri = result.assets[0].uri;
      let filename = localUri.split("/").pop(); 
 
      console.log("ufff3", localUri); 
      setLoader(true);

      const uploadImage4 = async ( ) => {
        const formData = new FormData();
        formData.append('file', {
          uri: Platform.OS === 'android' ? localUri : filename,
          type: 'image/jpeg',
          name: 'filename.jpg',
        });
      
        try {
          const response = await axios.post('https://goa-backend.onrender.com/api/photo', formData, {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          });
      
          console.log('4Image uploaded successfully4:', response.data.secure_url);
          setuploaded4(response.data.secure_url);
          setLoader(false);

        } catch (error) {
          console.error('Error uploading image:', error);
          setLoader(false);

        }
      };
      uploadImage4();
      
    }
    
  };

  function ratingCompleted(rating) {
     ratingst=rating;
    console.log("Rating is: "  + ratingst )
  }
  const next=async()=>{
setLoader(true);
console.log("res finding",name,ratingst,selectedLanguage,desc,"ek",uploaded2,"ek",uploaded3,"ek",uploaded4,"ek",uploaded)
    var senddata = {
      method: 'post',
      url: BASE_URL + PATH.ADD_PLACES,
      headers: {
        'Content-Type': 'application/json',
      },
      data: JSON.stringify({
        "place": name,
    "location": selectedLanguage,
    "description": desc,
    "rating":link,
    "image1": uploaded,
    "image2": uploaded2,
    "image3": uploaded3,
    "image4": uploaded4, 

      }),
    };
    
    await axios(senddata)
    .then((res) => { 
      console.log("me",res.data);   
            Alert.alert('Place added Successfully') 
            setLoader(false);
            navigation.goBack();
           
    })
    .catch((err) => { 
      console.log(err.response.data);
      Alert.alert('Some Error! Try again') 
      setLoader(false);
    });
  }
  

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={{ background: "#E5E5E5",marginBottom:window.width*0.2 }}>
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            marginTop: window.height * 0.035,
            marginHorizontal: window.width * 0.03,
          }}
        >
          {/* header  */}
          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
              flexDirection: "row",
              marginTop: window.width * 0.0,
            }}
          >
            {/* <Ionicons
              onPress={() => {
                navigation.goBack();
              }}
              name="chevron-back-circle-sharp"
              size={25}
              style={{
                marginLeft: -window.width * 0.2,
                width: window.width * 0.22,
              }}
            /> */}
            <Text
              style={{
                fontSize: 22,
                fontWeight: "bold",
                marginLeft: window.width * 0.0,
              }}
            >
              Add Spot
            </Text>
          </View>
        </View>
        {/* all input data field  */}
        <View style={{ marginHorizontal: window.width * 0.08 }}>
          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginTop: window.width * 0.1,
            }}
          >
            Name of Place
          </Text>
          <TextInput
            placeholder="Input placeholder"          
            style={{
              borderRadius: 5,
              borderWidth: 1,
              padding: window.width * 0.02,
              marginTop: window.width * 0.02,
              height: window.width * 0.15,
            }}
            value={name}
            onChangeText={e=>setName(e)}
          ></TextInput>

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginTop: window.width * 0.05,
            }}
          >
            Select Location
          </Text>

          <View
            style={{
              borderWidth: 1,
              height: window.width * 0.15,
              marginTop: window.width * 0.02,
              borderRadius: 4,
            }}
          >
            <Picker
              selectedValue={selectedLanguage}
              onValueChange={(itemValue, itemIndex) =>
                setSelectedLanguage(itemValue)
              }
            >
              <Picker.Item
                label="Input Placeholder8"
                value="Input Placeholder8"
              />
              <Picker.Item
                label="Input Placeholder7"
                value="Input Placeholder7"
              />
            </Picker>
          </View>

           

          {/*  description   */}

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginTop: window.width * 0.05,
            }}
          >
            Description
          </Text>
          <TextInput
            multiline={true}
            placeholder="Overview of Place"
            value={desc}
            onChangeText={e=>setdesc(e)}
            style={{
              borderRadius: 5,
              borderWidth: 1,
              padding: window.width * 0.02,
              marginTop: window.width * 0.02,
              height: window.width * 0.15,
            }}
          ></TextInput>

          {/* Rating   */}
{/* <View
style={{flexDirection:"row",
 alignItems:"center", 
 marginTop:window.width*0.05
}}
> */}



          <Text
            style={{
              fontSize: 14,
              fontWeight: "500", 
              marginTop:window.width*0.05
            }}
          >
Add Ratings
          </Text>
          <TextInput
            placeholder="Out of 5 "
            keyboardType="number-pad"
            value={link}
            onChangeText={e=>setlink(e)}
            style={{
              borderRadius: 5,
              borderWidth: 1,
              padding: window.width * 0.02,
              marginTop: window.width * 0.02,
              height: window.width * 0.15,
            }}
          ></TextInput>
{/* <Rating
  count={5}
   defaultRating={2}
  imageSize={25}
  tintColor="#E5E5E5"
  ratingBackgroundColor="#f5f5f5"
  type='custom' 
  onFinishRating={ratingCompleted}
  style={{marginLeft:window.width*0.025}}
/> */}

{/* </View> */}


          <View
            style={{
              marginTop: window.width * 0.02,
              justifyContent: "center",
              alignItems: "center",
              marginTop: window.width * 0.05,
            }}
          >
            <Text style={{ fontSize: 14, fontWeight: "500" }}>
              {" "}
              Upload Image{" "}
            </Text>
            
            <View style={{ flexDirection: "row", height: window.width * 0.5,justifyContent:"space-evenly",width:window.width*1,marginTop:window.width*0.01}}>
              {/* image 1  */}
              <TouchableOpacity
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  height: window.width * 0.5, 
                  width: window.width * 0.35,
                  backgroundColor: "#FFFFFF",
                  marginTop: window.width * 0.05,
                  borderRadius:window.width*0.02,
                }}
                onPress={() => {
                  pickImage();
                }}
              >
                {!image && (
                  <Image source={require("../assets/photo.png")}></Image>
                )}
                {image && (
                  <Image
                    source={{ uri: image }}
                    style={{
                      width: window.width * 0.35,
                      height: window.width * 0.5,
                    }}
                  />
                )}
              </TouchableOpacity>
{/* container 2 */}
              <View>
                {/* 2nd img */}
              <TouchableOpacity
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  height: window.width * 0.235,
                  width: window.width * 0.25,
                  backgroundColor: "#FFFFFF",
                  marginTop: window.width * 0.05,
                  
                  borderRadius:window.width*0.02,
                }}
                onPress={() => {
                  pickImage2();
                }}
              >
                {!image2 && (
                  <Image source={require("../assets/photo.png")}></Image>
                )}
                {image2 && (
                  <Image
                    source={{ uri: image2 }}
                    style={{
                      height: window.width * 0.235,
                      width: window.width * 0.25,
                    }}
                  />
                )}
              </TouchableOpacity>
                {/* 3nd img */}
              <TouchableOpacity
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  height: window.width * 0.235,
                  width: window.width * 0.25,
                  backgroundColor: "#FFFFFF",
                  marginTop: window.width * 0.03,
                  
                  borderRadius:window.width*0.02,
                }}
                onPress={() => {
                  pickImage3();
                }}
              >
                {!image3 && (
                  <Image source={require("../assets/photo.png")}></Image>
                )}
                {image3 && (
                  <Image
                    source={{ uri: image3 }}
                    style={{
                      height: window.width * 0.235,
                      width: window.width * 0.25,
                    }}
                  />
                )}
              </TouchableOpacity>

              </View>
              {/* last  */}
              <TouchableOpacity
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  height: window.width * 0.5,
                  width: window.width * 0.25,
                  backgroundColor: "#FFFFFF",
                  marginTop: window.width * 0.05,
                  borderRadius:window.width*0.02,
                }}
                onPress={() => {
                  pickImage4();
                }}
              >
                {!image4 && (
                  <Image source={require("../assets/photo.png")}></Image>
                )}
                {image4 && (
                  <Image
                    source={{ uri: image4 }}
                    style={{
                      height: window.width * 0.5,
                      width: window.width * 0.25,
                    }}
                  />
                )}
              </TouchableOpacity>
            </View>
          </View>

          

          {/* Submit button  */}

          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
              marginVertical: window.width * 0.05,
            }}
          >
            <TouchableOpacity
              style={{
                borderColor: "#00A3FF",
                borderRadius: 200,
                borderWidth:2,
                width: window.width * 0.9,
                height: window.width * 0.15,
                justifyContent: "center",
                alignItems: "center",
                marginVertical:window.width*0.1,
              }}
              onPress={() => next()}
            >
              <Text
                style={{
                  color: "#00A3FF",
                  fontSize: 16,
                  fontWeight: "500",
                }}
              >
                Sumbit
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
      <Spinner visible={loader} />

    </SafeAreaView>
  );
};

export default Like;

const styles = StyleSheet.create({
  container: {
     
    backgroundColor:"#E5E5E5"
  },
  safeContainerStyle: {
    flex: 1,
    margin: 20,
    justifyContent: "center",
  },
});
