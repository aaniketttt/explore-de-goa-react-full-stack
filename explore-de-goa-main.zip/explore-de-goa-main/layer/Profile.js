import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
} from "react-native";

import React, { useState } from "react";

import Ionicons from "@expo/vector-icons/Ionicons";
import AntDesign from "@expo/vector-icons/AntDesign";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";

const window = {
  width: Dimensions.get("window").width,
  height: Dimensions.get("window").height,
};

const Profile = ({ navigation }) => {
  const [image, setImage] = useState(null);
  const [name,setName]=useState('');
  const dataall=async()=>{
    setName(await AsyncStorage.getItem("username"))
  }
  dataall();
  const pickImage = async () => {
    // No permissions request is necessary for launching the image library
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    console.log(result);

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };
  return (
    <View style={styles.container}>
      {/* header */}
      <View style={styles.header}>
        <Text
          style={{
            fontSize: 22,
            color: "black",
            paddingLeft: window.width * 0.31,
            fontWeight: "600",
          }}
        >
          My Profile
        </Text>
      </View>

      {/* Image */}
      <TouchableOpacity
        onPress={() => {
          pickImage();
        }}
        style={{
          marginTop: window.width * 0.07,
          marginBottom: window.width * 0.05,
          flexDirection: "row",
          justifyContent: "center",
          alignContent: "center",
        }}
      >
        {!image && (
          <Image
            style={{ width: window.width * 0.35, height: window.width * 0.345 }}
            source={require("../assets/avt1.png")}
          />
        )}
        {image && (
          <Image
            source={{ uri: image }}
            style={{
              width: window.width * 0.35,
              height: window.width * 0.35,
              borderRadius: 200,
            }}
          />
        )}

        {/* <View>
          <Image
            style={styles.boxinside}
            source={require("../assets/camerasettingpic.png")}
          />
        </View> */}
      </TouchableOpacity>

      {/* Aniket Teli */}
      <Text style={{ fontSize: 18, fontWeight: "600", textAlign: "center",marginBottom:window.width*0.1 }}>
        {name}
      </Text>

      {/* profile section start  */}
      <TouchableOpacity
      // onPress={()=>{navigation.navigate('Profile')}}
      >
        {/* profile people_row */}
        <View style={styles.majorRow}>
          <Ionicons name="person-outline" color="black" size={25} />
          <Text
            style={{
              width: window.width * 0.6,
              fontWeight:"400",
              fontSize:16
            }}
          >
            Edit Profile
          </Text>
          <Ionicons
            style={
              {
                //  paddingLeft:window.width*0.12
              }
            }
            name="chevron-forward-outline"
            color="black"
            size={25}
          />
        </View>
      </TouchableOpacity>

      {/* profile section ends */}

      {/* password section */}

      <TouchableOpacity
      // onPress={()=>{navigation.navigate('Password')}}
      >
        <View style={styles.majorRow}>
        <Ionicons name="help-circle-outline" color="black" size={25} />
          <Text
            style={{
              width: window.width * 0.6,
              fontWeight:"400",
              fontSize:16
            }}
          >
            Help Center
          </Text>
          <Ionicons
            style={
              {
                //  paddingLeft:window.width*0.12
              }
            }
            name="chevron-forward-outline"
            color="black"
            size={25}
          />
        </View>
      </TouchableOpacity>

      {/* notification section */}
      <TouchableOpacity
        onPress={() => {
          // navigation.navigate("Notification");
        }}
      >
        <View style={styles.majorRow}>
        <Image
            style={{ width: window.width * 0.06, height: window.width * 0.06, marginLeft:window.width*0.01 }}
            source={require("../assets/invite.png")}
          />
          <Text
            style={{
              width: window.width * 0.6,
              fontWeight:"400",
              fontSize:16
            }}
          >
            Invite friends
          </Text>
          <Ionicons
            style={
              {
                //  paddingLeft:window.width*0.12
              }
            }
            name="chevron-forward-outline"
            color="black"
            size={25}
          />
        </View>
      </TouchableOpacity>

      {/* wallet section */}
      <TouchableOpacity
        onPress={() => {
          // navigation.navigate("Wallet");
        }}
      >
        {/* profile people_row */}
        <View style={styles.majorRow}>
        <Image
            style={{ width: window.width * 0.06, height: window.width * 0.06, marginLeft:window.width*0.009 }}
            source={require("../assets/about.png")}
          />
          
          <Text
            style={{
              width: window.width * 0.6,
              fontWeight:"400",
              fontSize:16
            }}
          >
            About Us
          </Text>
          <Ionicons
            style={
              {
                //  paddingLeft:window.width*0.12
              }
            }
            name="chevron-forward-outline"
            color="black"
            size={25}
          />
        </View>
      </TouchableOpacity>

      

       

      {/* delete Account */}
      <TouchableOpacity
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          marginTop:window.width*0.1
        }}
        onPress={()=>{ navigation.navigate("Getstarted")}}
      >
        <Text
          style={{
            // width: window.width * 1,
            fontSize: 16,
            color: "#a7abad",
            // marginTop: window.width * 0.05,
          }}
        >
          Log out{" "}
        </Text>
        <Image style={{marginLeft:window.width*0.01 ,width: window.width * 0.05, height: window.width * 0.05 }} 
        source={require("../assets/logout.png")} />
      </TouchableOpacity>
    </View>
  );
};

export default Profile;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
    backgroundColor: "white",
    paddingRight: window.width * 0.05,
    paddingLeft: window.width * 0.05,
    paddingTop: window.width * 0.1,
  },

  header: {
    // flex: 0.08,
    flexDirection: "row",
    alignItems: "center",
    paddingRight: window.width * 0.05,
    paddingBottom: window.width * 0.02,
    backgroundColor: "white",
    height: window.height * 0.08,
  },
  boxinside: {
    position: "absolute",
    marginTop: window.width * 0.2,
    marginLeft: -window.width * 0.1,
  },
  majorRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: window.width * 0.02,
    padding: window.width * 0.03,
  },
});
