import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
  SafeAreaView,
  FlatList
} from "react-native";
import Spinner from "react-native-loading-spinner-overlay/lib";
import React,{useEffect,useState} from "react";
import Ionicons from "@expo/vector-icons/Ionicons";
import { BASE_URL,PATH } from "../Api";
import axios from "axios";
import { useFocusEffect } from "@react-navigation/native";
import { useIsFocused } from '@react-navigation/native';

const window = {
  width: Dimensions.get("window").width,
  height: Dimensions.get("window").height,
};
const Notification = ({ navigation }) => {
  const [loader, setLoader] = useState(false);
  const [alldata,setAlldata]=useState([]);
  const isFocused = useIsFocused();

  useEffect(()=>{
    setLoader(true);
    var senddata = {
      method: 'get',
      url: BASE_URL + PATH.PLACES,
      headers: {
        'Content-Type': 'application/json',
      },
      data: {},
    };
    if (isFocused) {
      axios(senddata)
      .then((res) => { 
        console.log("data colllecting ",res.data.code);  
        if(res.data.code==200){
          setAlldata(res.data.data.reverse());
        } 
               setLoader(false); 
             
      })
      .catch((err) => { 
        console.log(err.response.data);
         setLoader(false);
      });
    } else {
      setLoader(false);

    }

   
    
  },[isFocused])
  return (
    <SafeAreaView>
      <View style={{ background: "#E5E5E5" }}>
        <View
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: window.height * 0.035,
            marginHorizontal: window.width * 0.03,
          }}
        >
          {/* header  */}
          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
              flexDirection: "row",
              marginTop: window.width * 0.01,
            }}
          >
            <Ionicons
              onPress={()=>{navigation.goBack()}}
              name="chevron-back-sharp"
              size={25}
              style={{
                marginLeft: -window.width * 0.3,
                width: window.width * 0.22,
              }}
            />
            <Text
              style={{
                fontSize: 22,
                fontWeight: "bold",
                marginLeft: window.width * 0.09,
              }}
            >
              Notification
            </Text>
          </View>
        </View>
        
      </View>

       
        <FlatList
            data={alldata}
            style={{ marginTop: window.width * 0.05,marginBottom:window.width*0.41 }}
            scrollEventThrottle={1}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false} 
            keyExtractor={(item, index) => (item.toString(), index.toString())}
            renderItem={({ item, index }) => {
              console.log(item)
              return (
                <>
              {/* row  */}
        <TouchableOpacity
          style={{ 
            // alignItems: "center",
            marginHorizontal: window.width * 0.1,
            marginTop: window.width * 0.1,
          }}

          onPress={()=>{
            // navigation.navigate('Messagescreen');
          }}
        >
          
          <View
            style={{
              elevation: 10,
              width: window.width * 0.8,
              height: window.width * 0.18,
              backgroundColor: "white",
              borderRadius: 5,
              justifyContent: "space-evenly",
              padding: window.width * 0.01,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Image source={{uri:item.image1}} style={{width:window.width*0.1,height:window.width*0.1,borderRadius:window.width*0.015}} />
            <Text style={{  width: window.width * 0.6,fontWeight:"600" }}>
              {" "}
              New photo has been uploaded! 
            </Text>
          </View>
            {/* circle  */}
            {/* <View style={{ borderRadius: 2000,
             backgroundColor: "#00B528",
             width:window.width*0.05,
             height:window.width*0.05,
             position:'absolute',
             zIndex:500,
             marginTop:-window.width*0.03,
             marginLeft:window.width*0.77,
             justifyContent:'center',
             alignItems:'center'
              }} >
                <Text style={{color:'white'}}>8</Text>
              </View> */}
        </TouchableOpacity>
                </>
              );
            }}
          />
          <Spinner visible={loader}/>
    </SafeAreaView>
  );
};

export default Notification;
