import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
  FlatList,
  Alert,
  TextInput,
} from "react-native";

import React, { useEffect, useState } from "react";
import { LinearGradient } from "expo-linear-gradient";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BASE_URL, PATH } from "../Api";
import Spinner from "react-native-loading-spinner-overlay";
import axios from "axios";
const window = {
  width: Dimensions.get("window").width,
  height: Dimensions.get("window").height,
};
const Places = ({ navigation }) => {
  const [loader, setLoader] = useState(false);
  const [place, setPlace] = useState(null);
  const [img1, setImg1] = useState(null);
  const [img2, setImg2] = useState(null);
  const [img3, setImg3] = useState(null);
  const [img4, setImg4] = useState(null);
  const [desc, setDesc] = useState(null);
  const [location, setLocation] = useState(null);
  const [rateshow, setrateshow] = useState(null);

  useEffect(() => {
    setLoader(true);
    const dataextract = async () => {
      var tempid = await AsyncStorage.getItem("placetoken");

      var senddata = {
        method: "post",
        url: BASE_URL + PATH.DETAILS,
        headers: {
          "Content-Type": "application/json",
        },
        data: JSON.stringify({
          _id: tempid,
        }),
      };
      await axios(senddata)
        .then((res) => {
          console.log("me", res.data);
          if (res.data.code == 200) {
             console.log(res.data.data[0]);
            setImg1(res.data.data[0].image1);
            setImg2(res.data.data[0].image2);
            setImg3(res.data.data[0].image3);
            setImg4(res.data.data[0].image4);
            setPlace(res.data.data[0].place);
            setDesc(res.data.data[0].description);
            setrateshow(res.data.data[0].rating);
            setLocation(res.data.data[0].location);
            
          }
          setLoader(false);
        })
        .catch((err) => {
          console.log(err);
          setLoader(false);
        });
    };
    dataextract();
  }, []);
  return (
    <>
      <View style={{ margin: window.width * 0.05, flexDirection: "column",   flex:1, }}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Image
            source={require("../assets/backbtn.png")}
            style={{ marginBottom: window.width * 0.05 }}
          />
        </TouchableOpacity>
        <View>
          <Image
            source={{ uri: img1 }}
            style={{
              width: window.width * 0.9,
              height: window.width * 0.9,
              borderRadius: window.width * 0.05,
            }}
          />
        </View>

        {/* over flow  */}
        <View
          style={{
            position: "absolute",
            marginTop: window.width * 0.5,
            marginLeft: window.width * 0.05,
          }}
        >
          <Text style={{ fontSize: 24, fontWeight: "600", color: "white" }}>
            {place}
          </Text>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Image source={require("../assets/redlocation.png")} />
            <Text
              style={{
                fontSize: 20,
                fontWeight: "700",
                color: "white",
                marginLeft: window.width * 0.02,
              }}
            >
              {location}
            </Text>
          </View>

          <View
            style={{
              justifyContent: "center",
              backgroundColor: "white",
              opacity: 0.4,
              marginTop: window.width * 0.02,
              width: window.width * 0.24,
              height: window.width * 0.1,
              borderRadius: 32,
            }}
          ></View>
          <Text
            style={{
              color: "white",
              fontSize: 16,
              fontWeight: "600",
              position: "absolute",
              marginTop: window.width * 0.19,
              marginLeft: window.width * 0.01,
            }}
          >
            100/Person
          </Text>
          {/* image list  */}
          <View
            style={{
              justifyContent: "space-between",
              height: window.width * 0.3,
              marginLeft: window.width * 0.65,
              marginTop: -window.width * 0.45,
            }}
          >
            <Image
              source={{ uri: img1 }}
              style={{
                width: window.width * 0.15,
                height: window.width * 0.15,
                marginVertical: window.width * 0.01,
              }}
            />
            <Image
              source={{ uri: img2 }}
              style={{
                width: window.width * 0.15,
                height: window.width * 0.15,
                marginVertical: window.width * 0.01,
              }}
            />
            <Image
              source={{ uri: img3 }}
              style={{
                width: window.width * 0.15,
                height: window.width * 0.15,
                marginVertical: window.width * 0.01,
              }}
            />
            <Image
              source={{ uri: img4 }}
              style={{
                width: window.width * 0.15,
                height: window.width * 0.15,
                marginVertical: window.width * 0.01,
              }}
            />
          </View>
        </View>
        {/* overview  */}

        <Text
          style={{
            color: "#EF7734",
            fontSize: 27,
            fontWeight: "700",
            marginTop: window.width * 0.05,
          }}
        >
          Overview
        </Text>
        {/* rating  */}
        <View
          style={{
            flexDirection: "row",
            marginTop: window.width * 0.05,
            justifyContent: "space-between",
          }}
        >
          <View style={{ flexDirection: "row" }}>
            <Image
              source={require("../assets/time.png")}
              style={{ width: window.width * 0.1, height: window.width * 0.1 }}
            />
            <View
              style={{
                flexDirection: "column",
                marginLeft: window.width * 0.02,
              }}
            >
              <Text
                style={{ color: "#9c9d9c", fontSize: 13, fontWeight: "500" }}
              >
                {" "}
                Trip Duration
              </Text>
              <Text
                style={{ color: "#000000", fontSize: 15, fontWeight: "600" }}
              >
                {" "}
                4 Days
              </Text>
            </View>
          </View>

          <View style={{ flexDirection: "row" }}>
            <Image
              source={require("../assets/star.png")}
              style={{ width: window.width * 0.1, height: window.width * 0.1 }}
            />
            <View
              style={{
                flexDirection: "column",
                marginLeft: window.width * 0.02,
              }}
            >
              <Text
                style={{ color: "#9c9d9c", fontSize: 13, fontWeight: "500" }}
              >
                Ratings
              </Text>
              <Text
                style={{ color: "#000000", fontSize: 15, fontWeight: "600" }}
              >
                {" "}
               {rateshow+" out of 5"}
              </Text>
            </View>
          </View>
        </View>
        {/* texts  */}
        <Text
          style={{
            fontSize: 16,
            color: "#868B8D",
            fontWeight: "400",
            marginTop: window.width * 0.05,
          }}
        >
          {desc}
        </Text>

        {/* linear  */}
        <LinearGradient
          colors={["transparent", "#F5F5F5"]}
          style={styles.background}
        />

        <View
          style={{
              // backgroundColor: "white", 
              position:"absolute",
         alignSelf:"center", 
            flexDirection: "row",
             bottom:0,
          }}
        >
          <View
            style={{
              backgroundColor: "#0070F4",
              padding: window.width * 0.03,
              width: window.width * 0.25,
              borderRadius: 45,
              justifyContent: "center",
              alignItems: "center",
              height: window.width * 0.15,
            }}
          >
            <Image source={require("../assets/download.png")} />
          </View>

          <View
            style={{
              backgroundColor: "#0070F4",
              padding: window.width * 0.02,
              paddingRight: window.width * 0.07,
              width: window.width * 0.55,
              height: window.width * 0.15,
              borderRadius: 45,
              justifyContent: "space-between",
              alignItems: "center",
              flexDirection: "row",
              marginLeft:window.width*0.05
            }}
          >
            <Text
              style={{
                color: "white",
                fontSize: 24,
                marginHorizontal: window.width * 0.02,
              }}
            >
              Book Now
            </Text>
            <Image source={require("../assets/forward.png")} />
          </View>

        </View>
      </View>
      <Spinner visible={loader} />
    </>
  );
};

export default Places;

const styles = StyleSheet.create({
  background: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    height: 150,
  },
});
