import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  ScrollView,
  FlatList,
  Alert,
  TextInput,
} from "react-native";

import React,{useEffect,useState} from "react";
import { BASE_URL, PATH } from "../Api";
import axios from "axios";
import Spinner from "react-native-loading-spinner-overlay";
import AsyncStorage from "@react-native-async-storage/async-storage";

const window = {
  width: Dimensions.get("window").width,
  height: Dimensions.get("window").height,
};

const Home = ({navigation}) => {
  const [loader, setLoader] = useState(false);
  const [alldata,setAlldata]=useState([]);
  const [name,setName]=useState('');
  const dataall=async()=>{
    setName(await AsyncStorage.getItem("username"))
  }
  dataall();
  useEffect(()=>{
    setLoader(true);
    var senddata = {
      method: 'get',
      url: BASE_URL + PATH.PLACES,
      headers: {
        'Content-Type': 'application/json',
      },
      data: {},
    };

     axios(senddata)
    .then((res) => { 
      console.log("data colllecting ",res.data.code);  
      if(res.data.code==200){
        setAlldata(res.data.data.reverse());
      } 
             setLoader(false); 
           
    })
    .catch((err) => { 
      console.log(err.response.data);
       setLoader(false);
    });
    
  },[])

  const next=async(idname)=>{
    await AsyncStorage.setItem("placetoken",String(idname));
    console.log(idname);
    navigation.navigate('Places')
  
  }
  return (<>
    <ScrollView
      style={{
        marginLeft: window.width * 0.08,
        marginTop: window.width * 0.08,
        flexDirection: "column",
      }}
    >
      <View
        style={{
          justifyContent: "flex-start",
          alignItems: "center",
          flexDirection: "row",
        }}
      >
        <Image source={require("../assets/profile.png")} />
        <Text style={{ color: "#626362", fontSize: 20, fontWeight: "400" }}>
          {" "}
          Hello,
        </Text>
        <Text style={{ color: "black", fontSize: 20, fontWeight: "400" }}>
          {name}
        </Text>
      </View>
      {/* Let goa 1 */}
      <View
        style={{
          justifyContent: "flex-start",
          alignItems: "center",
          flexDirection: "row",
          marginTop: window.width * 0.05,
        }}
      >
        <Text style={{ color: "black", fontSize: 32, fontWeight: "700" }}>
          {" "}
          Let’s travel to Goa{" "}
        </Text>
      </View>
      {/* Let goa 2  */}
      <View
        style={{
          justifyContent: "flex-start",
          alignItems: "center",
          flexDirection: "row",
          marginTop: window.width * 0.01,
        }}
      >
        <Text style={{ color: "#4182E4", fontSize: 32, fontWeight: "700" }}>
          {" "}
          dream vacation{" "}
        </Text>
        <Text style={{ color: "black", fontSize: 32, fontWeight: "700" }}>
          {" "}
          spot{" "}
        </Text>
      </View>

      {/* Search  */}
      <View
        style={{
          flexDirection: "row",
          borderWidth: 1,
          borderColor: "#B8B8B8",
          //   backgroundColor:"#E5E5E5",
          padding: window.width * 0.03,
          paddingHorizontal: window.width * 0.05,
          borderRadius: 35,
          marginTop: window.width * 0.05,
          marginRight: window.width * 0.08,
        }}
      >
        <Image source={require("../assets/search.png")} />
        <TextInput
          style={{
            flex: 1,
            marginLeft: window.width * 0.05,
          }}
          placeholder="Discover places"
        />
        <Image source={require("../assets/rings.png")} />
      </View>
      {/* scroll first  */}

      <ScrollView
        horizontal={true}
        showsHorizontalScrollIndicator={false}
        style={{ marginTop: window.width * 0.05 }}
      >
        {/* item 1  */}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 45,
            padding: window.width * 0.02,
            flexDirection: "row",
            flex: 1,
            backgroundColor: "#fefffe",
          }}
        >
          <Image source={require("../assets/mountains.png")} />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
            }}
          >
            Mountains
          </Text>
        </View>
        {/* item 2 */}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 45,
            padding: window.width * 0.02,
            flexDirection: "row",
            flex: 1,
            backgroundColor: "#fefffe",
            marginLeft: window.width * 0.03,
          }}
        >
          <Image source={require("../assets/rivers.png")} />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
            }}
          >
            Rivers
          </Text>
        </View>
        {/* item 3*/}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 45,
            padding: window.width * 0.02,
            flexDirection: "row",
            flex: 1,
            backgroundColor: "#fefffe",
            marginLeft: window.width * 0.03,
          }}
        >
          <Image source={require("../assets/beach.png")} />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
            }}
          >
            Beaches
          </Text>
        </View>
        {/* item 3*/}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 45,
            padding: window.width * 0.02,
            flexDirection: "row",
            flex: 1,
            backgroundColor: "#fefffe",
            marginLeft: window.width * 0.03,
          }}
        >
          <Image source={require("../assets/beach.png")} />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
            }}
          >
            Beaches
          </Text>
        </View>
        {/* item 3*/}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 45,
            padding: window.width * 0.02,
            flexDirection: "row",
            flex: 1,
            backgroundColor: "#fefffe",
            marginLeft: window.width * 0.03,
          }}
        >
          <Image source={require("../assets/beach.png")} />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
            }}
          >
            Beaches
          </Text>
        </View>
        {/* item 3*/}
        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 45,
            padding: window.width * 0.02,
            flexDirection: "row",
            flex: 1,
            backgroundColor: "#fefffe",
            marginLeft: window.width * 0.03,
          }}
        >
          <Image source={require("../assets/beach.png")} />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
            }}
          >
            Beaches
          </Text>
        </View>
      </ScrollView>

      {/* popular places  */}

      <View
        style={{
          marginRight: window.width * 0.08,
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginTop:window.width*0.05
        }}
      >
        <Text style={{ color: "#0070F4", fontSize: 24, fontWeight: "500" }}>
          Popular Places
        </Text>
        <Text
          style={{
            color: "rgba(0, 0, 0, 0.47)",
            fontSize: 15,
            fontWeight: "400",
          }}
        >
          Show more
        </Text>
      </View>

      {/* scroll main  */}

      <ScrollView 
        showsHorizontalScrollIndicator={false}
        style={{ marginBottom: window.width * 0.3 }}
      >
        {/* card scroll 1 */}
 

{ 
        <FlatList
            data={alldata}
            style={{ marginTop: window.width * 0.03 }}
            scrollEventThrottle={1}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
            horizontal={true}
            keyExtractor={(item, index) => (item.toString(), index.toString())}
            renderItem={({ item, index }) => {
              console.log(item)
              return (
                <>
             {index<4 &&     <TouchableOpacity
        onPress={()=>{
          next(item._id);

        }}
          style={{ 
            borderRadius: 30,
            padding: window.width * 0.02, 
            flex: 1,
            backgroundColor: "#FFFFFF",
            // height:window.width*0.75, 
            marginRight:window.width*0.06
          }}
        >
          <Image source={{uri:item.image1}} style={{width:window.width*0.5,height:window.width*0.5,borderRadius:window.width*0.05}}   />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
              marginVertical:window.width*0.02
            }}
          >
           {item.place}
          </Text>
          <View style={{flexDirection:"row",   
            marginHorizontal: window.width * 0.02,
}}>
          <Image source={require("../assets/location.png")} />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
              color:'#838283'
            }}
          >
           {item.location}
          </Text>

          </View>
        </TouchableOpacity> }

                </>
              );
            }}
          />}
        {/* card scroll 2 */}
        { 
        <FlatList
            data={alldata}
            style={{ marginTop: window.width * 0.05 }}
            scrollEventThrottle={1}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
            horizontal={true}
            keyExtractor={(item, index) => (item.toString(), index.toString())}
            renderItem={({ item, index }) => {
              console.log(item)
              return (
                <>
             {index>=4 &&     <TouchableOpacity
        onPress={()=>{
            next(item._id);
        }}
          style={{ 
            borderRadius: 30,
            padding: window.width * 0.02, 
            flex: 1,
            backgroundColor: "#FFFFFF",
            // height:window.width*0.75, 
            marginRight:window.width*0.06
          }}
        >
          <Image source={{uri:item.image1}} style={{width:window.width*0.5,height:window.width*0.5,borderRadius:window.width*0.05}}   />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
              marginVertical:window.width*0.02
            }}
          >
           {item.place}
          </Text>
          <View style={{flexDirection:"row",   
            marginHorizontal: window.width * 0.02,
}}>
          <Image source={require("../assets/location.png")} />
          <Text
            style={{
              marginHorizontal: window.width * 0.02,
              fontWeight: "400",
              fontSize: 15,
              color:'#838283'
            }}
          >
           {item.location}
          </Text>

          </View>
        </TouchableOpacity> }

                </>
              );
            }}
          />}


      </ScrollView>

    </ScrollView>
    <Spinner visible={loader} />

  
  </>
  );
};

export default Home;
